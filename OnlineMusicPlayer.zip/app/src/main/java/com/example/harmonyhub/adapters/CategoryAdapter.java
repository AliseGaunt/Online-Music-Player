package com.example.harmonyhub.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.harmonyhub.R;
import com.example.harmonyhub.SongsListActivity;
import com.example.harmonyhub.models.CategoryModel;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {
    private final List<CategoryModel> categoryList;

    public CategoryAdapter(List<CategoryModel> categoryList) {
        this.categoryList = categoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item_recycler_row, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        CategoryModel category = categoryList.get(position);
        holder.bindData(category);
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private final View itemView;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
        }

        public void bindData(CategoryModel category) {
            // Bind data to views
            TextView tvName = itemView.findViewById(R.id.tvName);
            ImageView imgvCoverImage = itemView.findViewById(R.id.imgvCoverImage);
            View categoryItem = itemView.findViewById(R.id.categoryItem);
            Context context = itemView.getContext();

            // Example of binding data:
            tvName.setText(category.getName());
            Glide.with(imgvCoverImage)
                    .load(category.getCoverUrl())
                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(32)))
                    .into(imgvCoverImage);

            // start SongsListActivity:
            categoryItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, SongsListActivity.class);
                    intent.putExtra("category", category);
                    context.startActivity(intent);
                }
            });
        }
    }
}
