package com.example.harmonyhub;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.harmonyhub.adapters.CategoryAdapter;
import com.example.harmonyhub.adapters.SectionSongListAdapter;
import com.example.harmonyhub.adapters.SongsListAdapter;
import com.example.harmonyhub.models.CategoryModel;
import com.example.harmonyhub.models.SongModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView song_title_text_view;
    ImageView song_cover_image_view;
    RelativeLayout player_view;
    ImageView optionBtn;
    androidx.appcompat.widget.SearchView search_bar;
    RecyclerView search_results;
    List<String> filteredList;
    androidx.recyclerview.widget.RecyclerView rvCategories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvCategories = findViewById(R.id.rvCategories);
        song_title_text_view = findViewById(R.id.song_title_text_view);
        song_cover_image_view = findViewById(R.id.song_cover_image_view);
        player_view = findViewById(R.id.player_view);
        optionBtn = findViewById(R.id.option_btn);
        search_bar = findViewById(R.id.search_view);
        search_results = findViewById(R.id.search_results_recycler_view);
        filteredList = new ArrayList<>();

        getCategories();
        setupSection("section_2", findViewById(R.id.section2MainLayout), findViewById(R.id.section_2_title), findViewById(R.id.section_2_recycler_view), this);
        setupSection("section_3", findViewById(R.id.section3MainLayout), findViewById(R.id.section_3_title), findViewById(R.id.section_3_recycler_view), this);

        optionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });

        search_bar.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (!hasFocus) {
                    search_results.setVisibility(View.GONE);
                }
            }
        });

        search_bar.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Action to perform when user submits query
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Action to perform as and when the text in search view changes
                if (newText.length() >= 3)
                {
                    // Filter your list based on newText and show filtered results
                    filter(newText);
                    return true;
                }
                return false;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        setupTrendingSection("section_1", findViewById(R.id.section1MainLayout), findViewById(R.id.section_1_title), findViewById(R.id.section_1_recycler_view));
    }

    void filter(String query) {
        filteredList.clear();
        search_results.setVisibility(View.VISIBLE);
        FirebaseFirestore.getInstance().collection("songs").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (DocumentSnapshot document : queryDocumentSnapshots) {
                            SongModel song = document.toObject(SongModel.class);
                            if (song.getTitle().toLowerCase().contains(query.toLowerCase())
                                    || song.getSubtitle().toLowerCase().contains(query.toLowerCase()))
                                {
                                    filteredList.add(song.getId());
                                }
                        }
                        setupSearchResultsView(filteredList);
                    }
                });
    }

    void setupSearchResultsView(List<String> filteredList) {
        SongsListAdapter songsListAdapter = new SongsListAdapter(filteredList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false);

        search_results.setLayoutManager(layoutManager);
        search_results.setAdapter(songsListAdapter);
    }

    void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, optionBtn);
        MenuInflater inflater = popupMenu.getMenuInflater();
        if (FirebaseAuth.getInstance().getCurrentUser() != null)
            inflater.inflate(R.menu.option_menu, popupMenu.getMenu());
        else
            inflater.inflate(R.menu.option_menu_1, popupMenu.getMenu());
        popupMenu.show();
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.logout) {
                    logout();
                    return true;
                }
                if (item.getItemId() == R.id.login)
                    login();
                return false;
            }
        });
    }

    void logout() {
        if (MyExoplayer.getInstance(getApplicationContext()) != null)
            MyExoplayer.getInstance(getApplicationContext()).stop();
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
        finish();
    }

    void login() {
        if (MyExoplayer.getInstance(getApplicationContext()) != null)
            MyExoplayer.getInstance(getApplicationContext()).stop();
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        showPlayerView();
    }

    //NOW PLAYING
    private void showPlayerView() {
        player_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PlayerActivity.class));
            }
        });
        SongModel currentSong = MyExoplayer.getCurrentSong();
        if (currentSong != null) {
            player_view.setVisibility(View.VISIBLE);
            song_title_text_view.setText(String.format("Now playing: " + currentSong.getTitle()));
            RequestOptions requestOptions = new RequestOptions().transform(new RoundedCorners(32));
            Glide.with(MainActivity.this)
                    .load(currentSong.getCoverUrl())
                    .apply(requestOptions)
                    .into(song_cover_image_view);
        } else {
            player_view.setVisibility(View.GONE);
        }
    }


    //CATEGORIES
    void getCategories() {
        Task<QuerySnapshot> category = FirebaseFirestore.getInstance()
                .collection("category")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<CategoryModel> categoryList = new ArrayList<>();
                        for (DocumentSnapshot document : queryDocumentSnapshots) {
                            CategoryModel category = document.toObject(CategoryModel.class);
                            categoryList.add(category);
                        }
                        setupCategoryRecyclerView(categoryList);
                    }
                });
    }

    void setupCategoryRecyclerView(List<CategoryModel> categoryList) {
        CategoryAdapter categoryAdapter = new CategoryAdapter(categoryList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL, false);

        rvCategories.setLayoutManager(layoutManager);
        rvCategories.setAdapter(categoryAdapter);
    }

    //SECTIONS
    public void setupSection(String id, RelativeLayout mainLayout, TextView titleView, RecyclerView recyclerView, Context context) {
        FirebaseFirestore.getInstance().collection("sections")
                .document(id)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    CategoryModel section = documentSnapshot.toObject(CategoryModel.class);
                    if (section != null) {
                        mainLayout.setVisibility(View.VISIBLE);
                        titleView.setText(section.getName());
                        recyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
                        recyclerView.setAdapter(new SectionSongListAdapter(section.getSongs()));
                        mainLayout.setOnClickListener(v -> {
                            SongsListActivity.category = section;
                            SongsListActivity.isTrending = false;
                            context.startActivity(new Intent(context, SongsListActivity.class));
                        });
                    }
                });
    }

    void setupTrendingSection(String id, RelativeLayout mainLayout, TextView titleView, RecyclerView recyclerView) {
        FirebaseFirestore.getInstance().collection("sections")
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        FirebaseFirestore.getInstance().collection("songs")
                                .orderBy("count", Query.Direction.DESCENDING)
                                .limit(5)
                                .get()
                                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                    @Override
                                    public void onSuccess(QuerySnapshot songListSnapshot) {
                                        List<SongModel> songsModelList = songListSnapshot.toObjects(SongModel.class);
                                        List<String> songsIdList = new ArrayList<>();
                                        for (SongModel songModel : songsModelList) {
                                            songsIdList.add(songModel.getId());
                                        }

                                        CategoryModel section = documentSnapshot.toObject(CategoryModel.class);
                                        if (section != null) {
                                            section.setSongs(songsIdList);
                                            mainLayout.setVisibility(View.VISIBLE);
                                            titleView.setText(section.getName());
                                            recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false));
                                            recyclerView.setAdapter(new SectionSongListAdapter(section.getSongs()));

                                            mainLayout.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    SongsListActivity.category = section;
                                                    SongsListActivity.isTrending = true;
                                                    Intent intent = new Intent(MainActivity.this, SongsListActivity.class);
                                                    startActivity(intent);
                                                }
                                            });
                                        }
                                    }
                                });
                    }
                });
    }

}