package com.example.harmonyhub.models;

import java.io.Serializable;
import java.util.List;

public class CategoryModel implements Serializable {
    private String name;
    private String coverUrl;
    private List<String> songs;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public List<String> getSongs() {
        return songs;
    }

    public void setSongs(List<String> songs) {
        this.songs = songs;
    }
}
