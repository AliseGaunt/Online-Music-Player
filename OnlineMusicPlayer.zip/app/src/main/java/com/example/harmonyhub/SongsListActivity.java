package com.example.harmonyhub;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.harmonyhub.adapters.SongsListAdapter;
import com.example.harmonyhub.adapters.TrendingSongsAdapter;
import com.example.harmonyhub.databinding.ActivitySongsListBinding;
import com.example.harmonyhub.models.CategoryModel;

public class SongsListActivity extends AppCompatActivity {

    public static CategoryModel category;
    public static boolean isTrending;
    private ActivitySongsListBinding binding;
    private SongsListAdapter songsListAdapter;
    private TrendingSongsAdapter trendingSongsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySongsListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (getIntent().getSerializableExtra("category") != null)
            category = (CategoryModel) getIntent().getSerializableExtra("category");

        binding.tvSongCategory.setText(category.getName());
        Glide.with(binding.imgvCategoryImage)
                .load(category.getCoverUrl())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(32)))
                .into(binding.imgvCategoryImage);

        Log.i("isTrending", String.valueOf(isTrending));
        setupSongsListRecyclerView(isTrending);
    }

    private void setupSongsListRecyclerView(boolean isTrending) {
        if (!isTrending)
        {
            songsListAdapter = new SongsListAdapter(category.getSongs());
            binding.rvSongsList.setLayoutManager(new LinearLayoutManager(this));
            binding.rvSongsList.setAdapter(songsListAdapter);
        }
        else
        {
            trendingSongsAdapter = new TrendingSongsAdapter(category.getSongs());
            binding.rvSongsList.setLayoutManager(new LinearLayoutManager(this));
            binding.rvSongsList.setAdapter(trendingSongsAdapter);
        }
    }
}