package com.example.harmonyhub.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.harmonyhub.MyExoplayer;
import com.example.harmonyhub.PlayerActivity;
import com.example.harmonyhub.R;
import com.example.harmonyhub.models.SongModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class SongsListAdapter extends RecyclerView.Adapter<SongsListAdapter.MyViewHolder> {

    private final List<String> songIdList;

    public SongsListAdapter(List<String> songIdList) {
        this.songIdList = songIdList;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        private final View itemView;
        private final TextView tvSongTitle;
        private final TextView tvSongSubtitle;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            tvSongTitle = itemView.findViewById(R.id.tvSongTitle);
            tvSongSubtitle = itemView.findViewById(R.id.tvSongSubtitle);
        }

        public void bindData(String songId) {
            FirebaseFirestore.getInstance().collection("songs")
                    .document(songId).get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            SongModel song = documentSnapshot.toObject(SongModel.class);
                            if (song != null) {
                                tvSongTitle.setText(song.getTitle());
                                tvSongSubtitle.setText(song.getSubtitle());
                                Glide.with(itemView.getContext())
                                        .load(song.getCoverUrl())
                                        .apply(RequestOptions.bitmapTransform(new RoundedCorners(32)))
                                        .into((ImageView) itemView.findViewById(R.id.imgvSongIcon));
                                itemView.setOnClickListener(view -> {
                                    MyExoplayer.startPlaying(itemView.getContext(), song);
                                    itemView.getContext().startActivity(new Intent(itemView.getContext(), PlayerActivity.class));
                                });
                            }
                        }
                    });
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.song_list_item_recycler_row, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.bindData(songIdList.get(position));
    }

    @Override
    public int getItemCount() {
        return songIdList.size();
    }
}