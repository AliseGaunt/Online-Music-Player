package com.example.harmonyhub;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.harmonyhub.databinding.ActivitySignupBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignupActivity extends AppCompatActivity {

    private ActivitySignupBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.createAccountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = binding.emailEdittext.getText().toString();
                String password = binding.passwordEdittext.getText().toString();
                String confirmPassword = binding.confirmPasswordEdittext.getText().toString();

                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    binding.emailEdittext.setError("Invalid email");
                    return;
                }

                if (password.length() < 6) {
                    binding.passwordEdittext.setError("Length should be 6 char");
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    binding.confirmPasswordEdittext.setError("Password not matched");
                    return;
                }

                createAccountWithFirebase(email, password);
            }
        });

        binding.gotoLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void createAccountWithFirebase(String email, String password) {
        setInProgress(true);
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        setInProgress(false);
                        Toast.makeText(getApplicationContext(),
                                "User created successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        setInProgress(false);
                        Toast.makeText(getApplicationContext(),
                                "Create account failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void setInProgress(boolean inProgress) {
        if (inProgress) {
            binding.createAccountBtn.setVisibility(View.GONE);
            binding.progressBar.setVisibility(View.VISIBLE);
        } else {
            binding.createAccountBtn.setVisibility(View.VISIBLE);
            binding.progressBar.setVisibility(View.GONE);
        }
    }

}